<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAppointmentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('appointments', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->dateTime('book_datetime');
			$table->dateTime('start_datetime');
			$table->dateTime('end_datetime');
			$table->text('notes', 65535);
			$table->binary('is_unavailable', 2);
			$table->integer('provider_user_id');
			$table->integer('contact_id');
			$table->dateTime('created_at');
			$table->dateTime('updateded_at');
			$table->index(['contact_id','provider_user_id'], 'contact_id');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('appointments');
	}

}
